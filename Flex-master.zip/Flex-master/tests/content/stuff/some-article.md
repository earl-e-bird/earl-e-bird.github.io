Title: Stuff Article
Date: 2016-02-01 12:00
Modified: 2016-02-01 12:00
Tags: article, world
Slug: stuff-article

This is an article with category stuff.