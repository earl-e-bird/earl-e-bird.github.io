Title: Some Article 4
Date: 2016-01-01 12:00
Modified: 2016-01-01 12:00
Tags: article, pelican, python
Slug: some-article-4

This is an article with category dev.