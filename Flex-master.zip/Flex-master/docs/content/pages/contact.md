Title: Contact
Date: 2015-07-18 08:00
Modified: 2018-01-01 08:00
Slug: contact

If you want to contact about typos, grammar and other errors in this blog, you can open an issue [here](https://github.com/alexandrevicenzi/Flex/issues).
