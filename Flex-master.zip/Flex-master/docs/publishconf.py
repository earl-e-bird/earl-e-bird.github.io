# -*- coding: utf-8 -*- #

import os
import sys

sys.path.append(os.curdir)

from pelicanconf import *

SITEURL = 'http://flex.alxd.me/blog'
RELATIVE_URLS = False
USE_LESS = False
GOOGLE_ANALYTICS = "UA-55543164-6"
