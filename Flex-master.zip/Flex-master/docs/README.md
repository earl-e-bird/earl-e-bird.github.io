# Flex Blog Example

## Build

`pelican -s pelicanconf.py`

## Publish

`pelican -s publishconf.py`
